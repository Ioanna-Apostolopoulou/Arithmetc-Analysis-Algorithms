function [ca , phi] = ask3

a = .............
ca = ..........
figure(3) ; clf; hold on
for k=0:360
    theta = 2*pi*k/360;
    v(1)=.............
    v(2)=...............
    u = ................
    phi(k+1) = ......................
    draw...... (....., 'b.');
    draw...... (.....,'m.');  
end
v=[sqrt(2)/2 ; sqrt(2)/2];
u = .....
draw......(v, 'k-s',{'v'});
draw......(u ,'k-s', {'u=a*v'}) ; 
hold off

figure(4)
plot([0:1:360] , ...........)
xlabel('v (se moires)')
ylabel('\phi (se moires)')

end
