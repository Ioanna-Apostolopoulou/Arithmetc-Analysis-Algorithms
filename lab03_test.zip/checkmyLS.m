%
function checkmyLS(AEM)

n = 100;
a = rand(n,n);
b = a*ones(n,1);
[L, U] = yota_lu(a);

%%students solutions
[x_stud] = myLS( L, b );

%%my solutions
[x_yota] = yota_lower_solve( L, b );

[mx, nx] = size(x_stud);
erx = 0;
if mx ~= n | nx ~= 1
   disp('**** La8os diastaseis to x. ****')
   erx = 1;
   return;
end

er1 = norm(x_stud-x_yota);

disp(' ')
disp('H synarthsh ekteleitai, +10');grade = 10;
if erx == 0  
    disp('Swsth diastash sto dianysma lyshs , +10');grade = grade+10;
end

if er1<10e-20
    disp('Swstoi oi ypologismoi gia th lysh toy katw trigwnikou systhmatos, +30');grade = grade+30;
else
    disp('**** La8os oi ypologismoi gia th lysh toy katw trigwnikou systhmatos. Debug it. ****');
end 

fprintf('Synolikos ba8mos %3d sta 50.\nKane Copy/Paste sthn katallhlh erwthsh sto socrative ton ari8mhtiko kwdiko sou %10d .\n', grade, 1234*grade+4321*AEM);

end

function [L, U] = yota_lu(A)
% Square A=LU factorization.
%
% Usage: [L, U] = my_lu(A)
% INPUT:
% A         - square invertible m-by-m matrix
% OUTPUT:
% L         - square m-by-m unit lower-triangular matrix;
% U         - square m-by-m upper-triangular matrix;
% ALGORITHM:
% L and U are computed by Gaussian elimination, 
% i.e., row exchange, so that L*U=A.
%
% Examples: 
%           A = randn(5); [L,U] = my_lu(A); 

[m, n] = size(A);
if m ~= n
   error('Matrix must be square.')
end
L = eye(n, n);
U = zeros(n, n);

for k = 1:n
   for i = k+1:n
      L(i, k) = A(i, k) / A(k, k);
      for j = k+1:n
         A(i, j) = A(i, j) - L(i, k)*A(k, j);
      end
   end
   for j = k:n
      U(k, j) = A(k, j);
   end
end

end

function [x] = yota_lower_solve( L, b )
%  Solves the system  L*x=b, where L is lower triangular matrix 

[m, n] = size(L);
if m ~= n
   error('Matrix must be square.')
end

x = zeros(n,1);
x(1) = b(1)/L(1,1);
for ii=2:1:n
    s = 0;
    for jj=1:1:ii-1
       s = s + x(jj)*L(ii,jj); 
    end
    x(ii) = (b(ii) - s)/L(ii,ii);       
end

end
