function [x] = myLS( L, b )
%  Solves the system  L*x=b, where L is lower triangular matrix 

[m, n] = size(L);
if m ~= n
   error('Matrix must be square.')
end

x = ....  % arxikopoihsh dianysmatos lyshs me katallhlh diastash

% algorithmos pros ta empros antikatastashs
x(1) = ......;
% Poia stoixeia toy x prepei na ypologis8oyn akomh kai me poia seira?
for ii=.... % symplhrwste katallhla ta oria toy deikth ii.
    s = 0;
    for jj= ... % poia ypologismena stoixeia toy x lambanoyme ypopsh mas
       s = s + ....; 
    end
    x(ii) = (b(ii) - .....) / .......;       
end

end

