%% Lyste me oles tis epanalhptikes me8odous to parakatw systhma kai melethste tis idiothtes twn me8odwn
%% ws pros to sfalma, to ypoloipo, to plh8os epanalhpsevn kai to xrono ana epanalhpsh kai synolika.
%%
%% Ylopoihste mia synarthsh poy 8a kaleitai [res_jac, res_gs, res_ak, res_cg] = compare_iteratives(n)
%% - Orisma eisagwghs h diastash toy pinaka, n (xrhsimopoihste times n=10^2 'i 10^3).
%% - Dhmioyrgeiste ton pinaka a ( nxn ) wste na einai o pentadiagvnios poy perigrafetai prin thn antistoixh entolh
%% - ftiakste to deksi meros ths a*x= b, wste to x (h lysh toy systhmatos) na einai dianysma me monades
%% 
%% - sto prwto meros xrhsimopoihste th jacobi2 swsta kai lyste to systhma
%% - ypologiste to ypoloipo apo oles tis prosseggiseis
%% - sto deytero meros xrhsimopoihste th gs2 swsta kai lyste to systhma
%% - ypologiste to ypoloipo apo oles tis prosseggiseis
%% - sto trito meros xrhsimopoihste thn ak2 gia na lysete to systhma
%% - ypologiste to ypoloipo apo oles tis prosseggiseis
%% - sto tetarto meros xrhsimopoihste thn cg2 gia na lysete to systhma
%% - ypologiste to ypoloipo apo oles tis prosseggiseis
%%
%% - sto dianysma (grammh) res_jac, apo8hkeyete ta ypoloipa apo th Jacobi
%% - sto dianysma (grammh) res_gs, apo8hkeyete ta ypoloipa apo th Gauss-Seidel
%% - sto dianysma (grammh) res_ak, apo8hkeyete ta ypoloipa apo th Apotomhs Ka8odou
%% - sto dianysma (grammh) res_cg, apo8hkeyete ta ypoloipa apo th Conjugate Gradient
%%
%% - Xrhsimopoihste Eykleidia norma opoy thn xreiasteite.
%%

function [res_jac, res_gs, res_ak, res_cg] = compare_iteratives(n, k)

%% dhmioyrghste katallhla ton a kai to b.
[a, b] = make_system(n, k);


%% x0 = arxikh proseggish ths lyshs,
%% eps = megisto apodekto sfalma sthn me8odo,  
%% maxiter = megistos ari8mos epanalhpsewn

x0  = zeros(n,1);
maxiter = 50;
tol = 0.5e-5;

figure(1); clf; hold on;
xlabel('iterations');
ylabel('log_{10} of diff on two consecutive approxim., ||.||_2');
hold on;
%% MEROS 1 - Jacobi
%% Kaleste swsta thn jacobi2 gia na lysete to systhma
%% sol_jac = oles oi proseggistikes lyseis toy systhmatos
%% err_jac = h diafora twn teleytaiwn diadoxikwn proseggisewn ths me8odou Jacobi
%% it_jac = plh8os epnalhpsewn pou eginan

display('Epilysh me Jacobi')
[sol_jac err_jac it_jac] = jacobi2(a, x0, b, tol, maxiter);


%% ypologismos ypoloipoy gia tis proseggiseis apo oles tis epanalhceis, apo th Jacobi
for ii=1:it_jac
  res_jac(ii) = norm(.....);
end

pause


%% MEROS 2 - Gauss-Seidel
%% Kaleste swsta thn gs2 gia na lysete to systhma
%% sol_gs = oles oi proseggistikes lyseis toy systhmatos
%% err_gs = h diafora twn teleytaiwn diadoxikwn proseggisewn ths me8odou Gauss-Seidel
%% it_gs = plh8os epanalhpsewn pou eginan
 
display('Epilysh me Gauss-Seidel')
[sol_gs err_gs it_gs] = gs2(a, x0, b, tol, maxiter);

%% ypologismos ypoloipoy gia tis proseggiseis apo oles tis epanalhceis, apo th Gauss-Seidel
for ii=1:it_gs
  res_gs(ii) = norm(....);
end
pause

%% MEROS 3 - Apotomhs ka8odou
%% Kaleste swsta thn ak2 gia na lysete to systhma
%% sol_ak = oles oi proseggistikes lyseis toy systhmatos
%% err_ak = h diafora twn teleytaiwn diadoxikwn proseggisewn ths me8odou Apotomhs Ka8odou
%% it_ak = plh8os epnalhpsewn pou eginan

display('Epilysh me Apotomhs Ka8odou')
[sol_ak err_ak it_ak] = ak2(a, x0, b, tol, maxiter);

%% ypologismos ypoloipoy gia tis proseggiseis apo oles tis epanalhceis, apo th Apotomhs Ka8odou
for ii=1:it_ak
  res_ak(ii) = norm(....);
end
pause

%% MEROS 4 - Syzygwn Klisewn
%% Kaleste swsta thn cg2 gia na lysete to systhma
%% sol_cg = oles oi proseggistikes lyseis toy systhmatos
%% err_cg = h diafora twn teleytaiwn diadoxikwn proseggisewn ths me8odou Syzygwn Klisewn
%% it_cg = plh8os epnalhpsewn pou eginan

display('Epilysh me Syzygwn Klisewn')
[sol_cg err_cg it_cg] = cg2(a, x0, b, tol, maxiter);

%% ypologismos ypoloipoy gia tis proseggiseis apo oles tis epanalhceis, apo th Syzygwn Klisewn
for ii=1:it_cg
  res_cg(ii) = norm(...);
end
disp('Markare me to pontiki th 8esh mesa sto figure, poy 8a mpei to legend') 
gtext([{'\color{red}Jacobi','\color{green}GS','\color{magenta}AK','\color{blue}CG'}]);

figure(2)
plot([1:it_jac], log10(res_jac), 'r*', [1:it_gs], log10(res_gs), 'g*', [1:it_ak], log10(res_ak), 'm*', [1:it_cg], log10(res_cg), 'b*' ),
xlabel('iterations');
ylabel('log_{10} of residual , ||.||_2');
disp('Markare me to pontiki th 8esh mesa sto figure, poy 8a mpei to legend') 
gtext([{'\color{red}Jacobi','\color{green}GS','\color{magenta}AK','\color{blue}CG'}]);

end

function [a, b] = make_system(n, k)

if k == 1
    a = ....;
elseif k==2
    a = ...;    
elseif k==3
    a = ...;
else 
    disp('La8os epilogh systhmatos');
    return;
end
    
xstar = ones(n,1);
b = a*xstar;

end
