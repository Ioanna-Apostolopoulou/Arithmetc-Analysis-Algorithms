%% Lyste me oles tis epanalhptikes me8odous to parakatw systhma kai melethste tis idiothtes twn me8odwn
%% ws pros to sfalma, to ypoloipo, to plh8os epanalhpsevn kai to xrono ana epanalhpsh kai synolika.
%%
%% Ylopoihste mia synarthsh poy 8a kaleitai [a, errors, res] = main(n)
%% - Orisma eisagwghs h diastash toy pinaka, n (xrhsimopoihste times n=10^2 'i 10^3).
%% - Dhmioyrgeiste ton pinaka a ( nxn ) wste na einai o pentadiagvnios poy perigrafetai prin thn antistoixh entolh
%% - ftiakste to deksi meros ths a*x= b, wste to x (h lysh toy systhmatos) na einai dianysma me monades
%%
%% - sto prwto meros symplhrwste th jacobi2 swsta kai xrhsimopoihste thn gia na lysete to systhma
%%
%% - sto deytero meros symplhrwste th gs2 swsta kai xrhsimopoihste thn gia na lysete to systhma
%%
%% - sto dianysma (grammh) errors, prepei na apo8hkeysete ta sfalmata twn me8odwn (me thn parapanw seira) apo th 5h epanalhpsh.
%% - omoia gia to dianysma (grammh) res, poy exei ta antistoixa ypoloipa tvn me8odwn (me thn idia seira) apo hn 5h epanalhpsh.
%%
%% - Xrhsimopoihste Eykleidia norma opoy thn xreiasteite.
%%

function [a, errors, res] = test_jac_gs(n)

a = ......;
xstar = ....;
b = .....;

%% arxikopoihsh twn epistrefomenvn orismatwn
errors = 10*ones(1, 2);
res = 10+zeros(1,2);

%% x0 = arxikh proseggish ths lyshs,
%% eps = megisto apodekto sfalma sthn me8odo,  
%% maxiter = megistos ari8mos epanalhpsewn

x0  = zeros(n,1);
maxiter = 50;
tol = 0.5e-5;

figure(1); clf; hold on;
xlabel('iterations');
ylabel('log_{10} of diff on two consecutive approxim., ||.||_2');
hold on;
%% MEROS 1 - Jacobi
%% Symplhrwste swsta thn jacobi2 kai kaleste thn gia na lysete to systhma
%% sol_jac = oles oi proseggistikes lyseis toy systhmatos
%% err_jac = oles oi normes twn diaforwn twn diadoxikwn proseggisewn ths me8odou Jacobi
%% it_jac = plh8os epnalhpsewn pou eginan

display('Epilysh me Jacobi')
[sol_jac err_jac it_jac] = jacobi2(a, x0, b, tol, maxiter);

%% ypologismos sfalmatos kai ypoloipoy gia thn 5h epanalhpsh, apo th Jacobi
errors(1) = norm(...);  
res(1) = norm(....);

pause


%% MEROS 2 - Gauss-Seidel
%% Symplhrwste swsta thn gs2 kai kaleste thn gia na lysete to systhma
%% sol_gs = oles oi proseggistikes lyseis toy systhmatos
%% err_gs = oles oi normes twn diaforwn twn diadoxikwn proseggisewn ths me8odou Gauss-Seidel
%% it_gs = plh8os epanalhpsewn pou eginan
 
display('Epilysh me Gauss-Seidel')
[sol_gs err_gs it_gs] = gs2(a, x0, b, tol, maxiter);

%% ypologismos sfalmatos kai ypoloipoy gia thn 5h epanalhpsh, apo th Jacobi
errors(2) = norm(.....);
res(2) = norm(....);
pause


disp('Markare me to pontiki th 8esh mesa sto figure, poy 8a mpei to legend') 
gtext([{'\color{red}Jacobi','\color{green}GS'}]);
hold off;
fprintf('Jacobi : 5h epanalhpsh : h norma tou sfalmatos einai %12.8f . \n',...
      errors(1) );
fprintf('GS : 5h epanalhpsh : h norma tou sfalmatos einai %12.8f . \n',...
      errors(2) );
fprintf('Jacobi : 5h epanalhpsh : h norma toy ypoloipoy ths proseggishs einai %12.8f . \n',...
      res(1) );
fprintf('GS : 5h epanalhpsh : h norma toy ypoloipoy ths proseggishs einai %12.8f . \n',...
      res(2) );
  
end

