%% 
%% compare the two implementations for timing purposes
%%
clear all; 

for ii=1:1:25
  n = 100*ii
  A = rand(n,n);
  ts1 = tic;
  [L, U] = my_lu(A);
  t1(ii) = toc(ts1);
  ts2 = tic;
  [L, U] = my_lu_fast(A);
  t2(ii) = toc(ts2);
  ts3 = tic;
  [L, U] = lu(A);
  t3(ii) = toc(ts3);
end
subplot(2,1,1)
plot(100*[1:25], t1,'b-*', 100*[1:25], t2,'r:*', 100*[1:25], t3,'g-.*')
legend('my lu','my lu fast','matlab lu')
xlabel('diastash pinaka')
ylabel('xronos (sec)')
subplot(2,1,2)
loglog(100*[1:25], t1,'b-*', 100*[1:25], t2,'r:*', 100*[1:25], t3,'g-.*')
legend('my lu','my lu fast','matlab lu')
xlabel('diastash pinaka')
ylabel('xronos (sec)')
  