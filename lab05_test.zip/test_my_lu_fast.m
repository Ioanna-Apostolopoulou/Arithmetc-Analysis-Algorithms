%% 
%% Xrhsimopoihste ayto to script gia na elegkste an exete programmatisei 
%% swsta th synarthsh my_lu_fast, h opoia pairnei orisma ena pinaka a, kai 
%% epistrefei toys pinakes L kai U apo thn LU-paragontopoihsh toy.
%% Gia na kanete ton elegxo, lyste to systhma Ax=b, xrhsimopoiontaw toyw L kai U.
%%
%% 
n = input('Diastash pinaka: ');
A = rand(n,n);
fprintf('O deikths katastashs toy pinaka A me thn 1-norma einai :  %12.8f \n',......);
x = ......; % dianysma me monades
b = .....;  % deksi meros ths ejiswshs

[L, U] = my_lu_fast(A);
% lysh systhmatos me xrhsh tvn pinakwn L kai U
x_comp = ........;
fprintf('H 1-norma ths diaforas x-x_comp einai :  %12.8f \n',norm(x-x_comp,1));

