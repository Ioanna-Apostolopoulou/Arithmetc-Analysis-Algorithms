function [ L, U] = my_lu( A )
%MY_LU Summary of this function goes here
%   Detailed explanation goes here

[m, n] = size(A);
if m ~= n
   error('Matrix must be square.')
end
L = eye(n, n);
U = zeros(n, n);

for k = 1:n
   for i = k+1:1:n
      L(i, k) = A(i, k) / A(k, k);
      for j = k+1:1:n
         A(i, j) = A(i, j) - L(i, k)*A(k, j);
      end
   end
   for j = k:n
      U(k, j) = A(k, j);
   end
end

end

