%% onomatepwnymo = .......
%% userID = .......
%% AEM = .......

function res = simpson(x,y)

n = ............  %% plh8os diasthmatwn. Poia h sxesh toy plh8ous diasthmatwn me to plh8os tvn shmeivn kai ara to plh8os twn stoixeiwn toy x???
h = ....................  %% platos diamerishs

if .....   %% aparaithtos elegos gia th swsth ylopoihsh ths Simpson
   res =.................
else
   res = NaN;
   fprintf('Error:: H meqodos Simpson den mporei na klhqei. La8os plh8os shmeiwn.\n');
end
