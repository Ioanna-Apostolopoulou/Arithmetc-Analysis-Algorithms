%% onomatepwnymo = .......
%% userID = .......
%% AEM = .......
function [olok, oloktra, errtrap, oloksim, errsim] = ask2

h = inline('sin(x)');
olok = .......  % ypologismos toy oloklhromatos me gnwseis Logismou I

ii= 1;
for n=5:2:201
x = linspace(0, pi, n);
y = h(x);
oloktra(ii) =  .......  % ypologismos toy oloklhromatos me me8odo Trapeziou
errtrap(ii) = .......  % ypologismos toy sflamatos me me8odo Trapeziou
oloksim(ii) = .......  % ypologismos toy oloklhromatos me me8odo Simpson
errsim(ii) = .......  % ypologismos toy sflamatos me me8odo Simpson
ii = ii+1;
end
figure(1)
plot([5:2:201], oloktra, [5:2:201], oloksim)
xlabel('# shmeiwn diakritopoihshs')
ylabel('oloklhrwma')
legend('Trapezio','Simpson')
figure(2)
loglog([5:2:201], errtrap, 'b',[5:2:201],([5:2:201]-1).^(-2) ,'m', ...
       [5:2:201], errsim, 'g',[5:2:201],([5:2:201]-1).^(-4) ,'r')
xlabel('# shmeiwn diakritopoihshs')
ylabel('sfalma oloklhrwmatos')
legend('Trapezio','klhsh -2', 'Simpson', 'klhsh -4')

end