function [A, B, C, D] = ask2(n)

% Symplhrwste katallhla to arxeio wste na ikanopoiei tis apaithseis ths
% askhshs 2.
A = ......;
B = ....;
C = ....;
D = .....;

end