function [x , y, theta] = ask1(k,n)

% Symplhrwste katallhla to arxeio wste na ikanopoiei tis apaithseis ths
% askhshs 1. 

% Ypologiste theta, x, kai y . Mhn allaksete ta onomata twn metablhtwn. 
theta = ...;
x = ...;
y = ...;

% Graphics
plot(x,y)
axis equal
xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 14)
ylabel('$y$', 'Interpreter', 'latex', 'FontSize', 14)
title('Logarithmic Spiral','Interpreter','latex','FontSize', 16)

end