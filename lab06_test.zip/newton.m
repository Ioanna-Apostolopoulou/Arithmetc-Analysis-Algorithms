%% H synarthsh newton ylopoiei th me8odo tou Newton gia thn 
%% eyresh ths rizas ths synarthshs f(x) = x^2*sin(x) me arxikh timh to x0.
%% H synarthsh kaleitai me [xstar, fxstar,  iter] = newton(x0, tol, maxiter)
%% opou :
%% x0 = arxikh timh
%% tol = anoxh sto sfalma
%% maxiter = megisto plh8os synarthsewn
%% xstar = proseggish thw rizas
%% fxstar = timh ths synarthshs sth riza
%% iter = plh8os epanalhpsewn poy ektelesthkan
%%


function [......] = newton(....)
%% block kwdika poy den prepei na allaksete
global f df
%% telos block kwdika poy den prepei na allaksete

%% Oriste swsta tis synarthseis f kai df wste na doyleyoyn kai an ta x, y einai dianysmata
f = inline('......'); %% h ekfrash ths x^2*sin(x) metatrepetai se synarthsh
df =  inline('..........');  %% ypologismos ths paragwgoy ths sygkekrimenhs synarthshs

plot(x0, 0,'ks'); 

xold = x0;
fxold = ...... ; %% timh ths f sto xold
dfxold = .......;  %% timh ths df sto xold
iter = 0;

if  abs(fxold) < tol
   fprintf('H synarthsh mhdenizetai sthn arxikh timh %f .\n',xold);
   xstar = xold;
   fxstar = ....
   return;
end

if  abs(dfxold) < ......
   fprintf('H paragwgos mhdenizetai sto %f kai h me8odos Newton den mporei na synexisei.\n',xold);
   xstar = ....
   fxstar = ....
   return;
end

%% 1h epanalhpsh eksw apo to while loop
xnew = ....  %% efarmogh ths me8odou Newton gia ypologismo 1hs proseggishs ths lyshs
fxnew = ....   %% timh ths f sto xnew
iter = ...   %% ayksanetai o deikths twn epanalhpsewn

plot(xnew, 0,'go');

while ...........................
   xold = ...
   fxold = .. 
   dfxold = .....
   if abs(dfxold) >= ....
      xnew = ...
      fxnew = ...
      iter = iter + 1 ;
      plot(xnew, 0,'go');
   else
      fprintf('H paragwgos mhdenizetai sto %f kai h me8odos Newton den mporei na synexisei.\n',xold);
      xstar = xnew;
      fxstar = fxnew;
      return;
   end

end

%% block kwdika poy den prepei na allaksete
xstar = xnew;
fxstar = fxnew;
plot(xstar,0,'r*');
%% telos block kwdika poy den prepei na allaksete
end