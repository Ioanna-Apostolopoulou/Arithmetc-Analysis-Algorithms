%% H synarthsh newton ylopoiei th me8odo tou Newton gia thn 
%% eyresh ths rizas twn synarthsewn 
%% F1(X,Y) = 1-4*X+2*X.*X-2*Y.^3
%% F2(x,Y) = -4 +4*X.^4+4*Y+4*Y.^4
%% me arxikh timh to x0.
%% x0 = arxikh timh
%% tol = anoxh sto sfalma
%% maxiter = megisto plh8os synarthsewn
%% xstar = proseggish thw rizas
%% fxstar = timh ths synarthshs sth riza
%% iter = plh8os epanalhpsewn poy ektelesthkan
%%


function [... , ..... , .....] = newton2(....  , ..... , .....)
%% block kwdika poy den prepei na allaksete
global f1 f2 df1dx df1dy df2dx df2dy
%% telos block kwdika poy den prepei na allaksete

%% Oriste swsta tis synarthseis f* kai df*d* wste na doyleyoyn kai an ta x, y einai dianysmata
f1 = inline('.............' ,'x','y'); %% grapste toys swstous typous ths 1hs synistwsas ths f
f2 = inline('.............' ,'x','y'); %% grapste toys swstous typous ths 2hs synistwsas ths f

df1dx = inline('...', 'x')  ; %% ypologiste kai grapste tis paragwgous opws fainetai apo ta onomata tvn metablhtvn
df1dy = inline('...', 'y')  ;
df2dx = inline('...', 'x')  ;
df2dy = inline('...', 'y')  ;

plot([x0(1)],[x0(2)],'k*', [x0(1)],[x0(2)],'ks');

xold = x0;
%% h fxold einai dianysma, ara sto Matlab einai sthlodianysma
%% kai periexei thn timh twn synarthsewn f* sto xold
fxold = ....  ;
%% DFxold einai pinakas kai periexei tis times twn 
%% parapanw paragwgwn sto xold
DFxold = ....    ;
    
iter = 0;

if  cond(DFxold) > 10^7
   fprintf('O pinakas me tis paragwgoys exei deikth katastashs %f sto (%f , %f) kai h me8odos Newton den mporei na synexisei.\n',cond(DFxold),xold(1), xold(2));
   xstar = xold;
   fxstar = fxold;
   return;
end

%% 1h epanalhpsh eksw apo to while loop
%% to xnew einai dianysma, ara sto Matlab einai sthlodianysma
xnew = ....;
%% h fxnew einai dianysma, ara sto Matlab einai sthlodianysma
%% kai periexei thn timh tvn synarthsewn f* sto xnew
fxnew = ......;
iter = ...  ;  %% ayksanetai o deikths twn epanalhpsewn

plot([xnew(1)],[xnew(2)],'m*');

while ........
   xold = xnew;
   fxold = fxnew; 
   DFxold = .......
   if cond(DFxold) <= 10^7
      xnew = ....
      fxnew = .....
      iter = iter + 1 ;
      plot([xnew(1)],[xnew(2)],'m*');
   else
      fprintf('O pinakas me tis paragwgoys exei deikth katastashs %f sto (%f , %f) kai h me8odos Newton den mporei na synexisei.\n',cond(DFxold),xold(1), xold(2));
      xstar = xnew;
      fxstar = fxnew;
      return;
   end
end

xstar = xnew;
fxstar = [f1(xnew(1), xnew(2)) ; f2(xnew(1), xnew(2))];
plot([xstar(1)],[xstar(2)],'r*',[xstar(1)],[xstar(2)],'ro'); 
end


