function dographics(X,Y,R,Z)
mini = min( min(min(R)), min(min(Z)) );
maxi = max( max(max(R)), max(max(Z)) );

figure(1); clf;
colormap(jet);

cax1 = subplot(1,2,1);
s=surfc(X,Y,R);
s(1).EdgeColor = 'none';
s(2).LevelList = [-5:1:5 ];
s(2).ShowText='on';
caxis(cax1, [mini maxi]);
xlabel('x'); 
ylabel('y');

cax2 = subplot(1,2,2);
s=surfc(X,Y,Z);
s(1).EdgeColor = 'none';
s(2).LevelList = [-5:1:5 ];
s(2).ShowText='on';
caxis(cax2, [mini maxi]);
xlabel('x'); 
ylabel('y');

figure(2); clf;
colormap(jet);

contour(X,Y,R,[-1 0 1]);
hold on; 
[C,h] = contour(X,Y,Z,[-1 0 1]); axis tight;
xlabel('x'); 
ylabel('y');
set (h, 'ShowText','on','TextStep',get(h,'LevelStep')*1)
grid;
end