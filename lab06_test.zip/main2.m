clc; clear all

[X,Y] = meshgrid(-2:.005:2);
R = 1-4*X+2*X.*X-2*Y.^3;
Z = -4 +4*X.^4+4*Y+4*Y.^4;

dographics(X,Y,R,Z);

x0 = [1 -0.5]';% [1 -0.5]'; %[0.5  0.7]';% [1  -0.2]';  %%diafores arxikes times
tol = 1.e-10;
maxiter = 20;

[xstar, fxstar, iter] = newton2(x0, tol, maxiter);%evresh ths dejias rizas
if iter == 0 
  fprintf('NEWTON: H me8odos den efarmosthke.\n');
else
  fprintf('NEWTON: H riza ( %f  %f)  vre8hke se %d epanalhpseis.\n',xstar(1) , xstar(2), iter);
end

hold off;


