function y = myNewton(xinterp,yinterp, x)
% H synarthsh myNewton ypologizei thn timh toy polywnymou parembolhs me
% anaparastash Newton, se ena shmeio h perissotera shmeia poy briskontai sto x
% Orismata eisodou::
%
% xinterp = sthlodianysma me tis tetmhmenes twn kombwn ths parembolhs
%
% yinterp = sthlodianysma me tis tetagmenes tvn kombwn ths parembolhs
%
% x = to shmeio h ta shmeia sta opoia 8eloume na ypologisoyme to polywnymo.
%       Sthn periptwsh poy einai polla shmeia, prosoxh to x na einai
%       sthlodianysma.
% Orismata epistrofhs: 
% y = h timh h oi times toy polywnymoy sto x. An x sthlodianysma tote tkai
%       to y einai sthlodianysma

plh8osKombwn = ....; %plh8os kombwn parembolhs

% dhmioyrgia pinaka gia to systhma me th me8odo Newton
mat = zeros(plh8osKombwn); % desmeysh xvrou gia ton pinaka. Katallhlh arxikopoihsh.
mat(:,1) = .....;  % swstes times sthn 1h sthlh
for j = 2:plh8osKombwn
    % swstes times se oles tis sthles, me epanalhptikh diadikasia poy
    % syndeei tis diadoxikes sthles. Symbouleyteite th 8ewria.
   mat(j:plh8osKombwn, j) = .......;    
end

% lysh systhmatos kai ypologismos syntelestwn c
c = ......;

% ypologismos timhs toy polywnymoy parembolhs me anaparastash Newton
m = length(x); % plh8os shmeiwn sta opoia ypologizoyme to polywnymo
y = ones(m,1) * c(1); % desmeysh xwrou katallhlhs diastashs gia na apo8hkey8oun 
                % oi times toy polyvnymou. Katallhlh arxikopoihsh tou y

for i = 2 : plh8osKombwn
   % ypologismos toy polyvnymoy me bash thn anaparastashs Newton.
   % ta mypi einai boh8htikh synarthsh poy ylopoiei ta polywnyma ths bashs
   % Newton
   % Symboyleyteite th 8ewria gia ton typo tous.
   y = .......;    
end

end

%%
% Synarthsh mypi, orath mono mesa se ayto to arxeio.
% Ylopoiei th formula twn polywnymwn p_i(x) apo th 8ewria kai ypoligizei 
% tis times twn polywnymwn bashs toy Newton
%
function yy = mypi(i,xinterp, m, x)
% Orismata eisodou:
% i = o deikths toy polywnymoy
% xinterp = sthlodianysma me tis tetmhmenes twn kombwn ths parembolhs
% m = plh8os shmeiwn sta opoia ypologizoyme to polywnymo
% x = to shmeio h ta shmeia sta opoia 8eloume na ypologisoyme to polywnymo.
%       Sthn periptwsh poy einai polla shmeia, prosoxh to x na einai
%       sthlodianysma.
% Orismata epistrofhs:
% yy = h timh h oi times toy polywnymoy p_i sto x. An x sthlodianysma tote tkai
%       to y einai sthlodianysma
 
yy = ones(m,1);
for k= .....
    yy = yy .* .......; 
end


end