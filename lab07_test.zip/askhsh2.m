%% H synarthsh askhsh1 xrhsimopoiei me8odous parembolhs
%% gia na ypologisei times ths 8ermokrasias se sygkekrimenes wres thw hmeras.
%% H synarthsh kaleitai ws value = askhsh2(t, method) opou 
%%
%% value = h timh / oi times ths 8ermokrasias stis wres poy pernoyn sto t ( ari8mos i sthlodianysma)
%%
%% t = h wra / oi wres poy endiaferomaste na ypologisoyme th 8ermokrasia ( ari8mos i sthlodianysma)
%%
%% method = flag poy boh8a na epileksoume me8odo parambolhs
%%           0 = polywnymikh parembolh
%%           1 = grammikh spline
%%           2 = kybikh spline (spline)
%%           3 = Kybikh spline pchip (pchip)
%%           4 = efarmozontai kai oi 4 me8odoi gia oles tis pi8anes xronikes stigmes
%%               edw h value einai pinakas opou h prvth sthlh periexei 
%%               ta apotelsmata gia th polywnymikh parembolh, 
%%               h deyterh ta apotelesmata apo thn grammikh spline  
%%               h trith ta apotelesmata apo thn kybikh spline kai 
%%               h tetarth ta apotelesmata apo thn pchip kybikh spline
%% gia logoys oikonomias xronoy oi gnvstes times ths 8ermokarsias/wras 
%% einai ka8orismenes mesa sth synarthsh stis metablhtes therm kai time


function .... = askhsh2( .... )

time = [0:4:24]';
therm = [15 14.2  12.8  13.9 17  16.8 15.5 ]';

n = length(t);     
if method == 4
    value = zeros(....  %% allocate proper space for the value variable
else
    value = zeros(....  %% allocate proper space for the value variable
end

tplot = linspace(0,24,145);

if method == 0 %% ypologismos polywnymou parembolhs
    m = ......;  %% o pinakas toy systhmatos
    synt = ......;             %% lysh systsmatos
    value = .....; %% ypologismos twn timwn tou polyvnymou-mononyma sta shmeia t.
    vplot = .....; %% ypologismos twn timwn tou polyvnymou-mononyma sta shmeia tplot.
    plot(time, therm, 'k*', tplot, vplot, '-b', t, value, '*b')
    legend('data', 'polynomial', 'value')
elseif method == 1 %% ypologismos grammikhs spline
    value = interp1(...); %% ypologismos twn timwn ths spline sta shmeia t.
    vplot = interp1(...); %% ypologismos twn timwn ths spline sta shmeia tplot.
    plot(time, therm, 'k*', tplot, vplot, '-r', t, value, '*r')
    legend('data', 'linear spline', 'value')
elseif method == 2 %% ypologismos kybikhs spline (spline)
    value = interp1(...); %% ypologismos twn timwn ths spline sta shmeia t.
    vplot = interp1(.....); %% ypologismos twn timwn ths spline sta shmeia tplot.
    plot(time, therm, 'k*', tplot, vplot, '-m', t, value, '*m')
    legend('data', 'kybikh spline', 'value')
elseif method == 3 %% ypologismos pchip kybikhs spline (pchip)
    value = interp1(.....);  %% ypologismos twn timwn ths spline sta shmeia t.
    vplot = interp1(........);  %% ypologismos twn timwn ths spline sta shmeia tplot.
    plot(time, therm, 'k*', tplot, vplot, '-g', t, value, '*g')
    legend('data', 'pchip kybikh spline', 'value')
elseif method == 4 %% oles oi me8odoi mazi
    m = ..
    synt = ...
    value.... = ...;
    value.... = interp1(.....'linear');
    value.... = interp1(....,'spline');
    value.... = interp1(....,'pchip');

    vplot1 = ....;
    vplot2 = interp1(....);
    vplot3 = interp1(....);
    vplot4 = interp1(....);
    plot(time, therm, 'k*', tplot, vplot1, '-b', t, value(:,1), '*b', ...
        tplot, vplot2, '-r', t, value(:,2), '*r', ...
        tplot, vplot3, '-m', t, value(:,3), '*m',...
        tplot, vplot4, '-g', t, value(:,4), '*g')
    legend('data', 'polynomial', 'value', 'linear spline', 'value','kybikh spline', 'value','HERMITE kybikh spline', 'value' )
else
    disp('Wrong method');
    value = 88888;
    return
end
xlabel('wres sth diarkeia ths hmeras')
ylabel('thermokrasia')
end

