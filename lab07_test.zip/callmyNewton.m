%% Script gia grhgorh klish ths myNewton

time = [0:4:24]';
therm = [15 14.2  12.8  13.9 17  16.8 15.5 ]';
tplot = linspace(0,24,145)';

%t = 1.5;
t = [ 0.5, 1.5, 2.25, 12.75, 18.5, 22.33 ]';

value = myNewton(time, therm, t);
vplot = myNewton(time, therm, tplot);
plot(time, therm, 'k*', tplot, vplot, '-g', t, value, '*g')
legend('data', 'Newton', 'value')