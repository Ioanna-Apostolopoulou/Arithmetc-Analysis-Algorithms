%% H synarthsh askhsh1 xrhsimopoiei me8odous parembolhs
%% gia na ypologisei times ths 8ermokrasias se sygkekrimenes wres thw hmeras.
%% H synarthsh kaleitai ws value = askhsh1(t, method) opou 
%%
%% value = h timh / oi times ths 8ermokrasias stis wres poy pernoyn sto t ( enas ari8mos i sthlodianysma)
%%
%% t = h wra / oi wres poy endiaferomaste na ypologisoyme th 8ermokrasia ( ari8mos i sthlodianysma)
%%
%% method = flag poy boh8a na epileksoume me8odo parambolhs
%%           0 = polywnymikh parembolh me anaparastash mononymwn
%%           1 = polywnymikh parembolh me anaparastash Newton
%%           2 = efarmozontai kai oi 2 me8odoi gia oles tis pi8anes xronikes stigmes
%%               edw h value einai pinakas opou h prwth sthlh periexei 
%%               ta apotelsmata gia thn anaparastash mononymwn kai
%%               h deyterh ta apotelesmata apo thn anaparastash Newton
%% gia logoys oikonomias xronoy oi gnwstes times ths 8ermokarsias/wras 
%% einai ka8orismenes mesa sth synarthsh stis metablhtes therm kai time
%% Fysika oles oi me8odoi 8a prepei na peistrefoyn ta idia apotelesmata.


function .... = askhsh1(.........)

time = [0:4:24]';
therm = [15 14.2  12.8  13.9 17  16.8 15.5 ]';

n = length(t);     
if method == 2
    value = zeros(.....); %% allocate proper space for the value variable. Deite grammh 4 sta sxolia
else
    value = zeros(.....); %% allocate proper space for the value variable. Deite grammh 4 sta sxolia
end

tplot = linspace(0,24,145)'; %% dhmioyrgia pollwn shmeiwn sto xrono (ana 10lepto) gia omales garfikes parastaseis

if method == 0  %% ypologismos me anaparastash mononymwn
    m = ......;  %% o pinakas toy systhmatos
    synt = ......;             %% lysh systsmatos
    value = .....; %% ypologismos twn timwn tou polyvnymou-mononyma sta shmeia t.
    vplot = .....; %% ypologismos twn timwn tou polyvnymou-mononyma sta shmeia tplot.
    plot(time, therm, 'k*', tplot, vplot, '-b', t, value, '*b')
    legend('data', 'polynomial', 'value')
elseif method == 1 %% ypologismos me anaparastash Newton
    value = myNewton(.......);   %% ypologismos twn timwn tou polyvnymou-Newton sta shmeia t.
    vplot = myNewton(.......);  %% ypologismos twn timwn tou polyvnymou-Newton sta shmeia tplot.
    plot(time, therm, 'k*', tplot, vplot, '-g', t, value, '*g')
    legend('data', 'Newton', 'value') %% oles oi me8odoi mazi
elseif method == 2
    m = .......;
    synt = .....;
    value(:,1) = ........;
    value(:,2) = myNewton(.....);
    
    vplot1 = ......;
    vplot2 = myNewton(........);
    plot(time, therm, 'k*', tplot, vplot1, '-b', t, value(:,1), '*b', ...
        tplot, vplot2, '-r', t, value(:,2), '*r')
    legend('data', 'polynomial', 'value', 'Newton', 'value' )
else
    disp('Wrong method');
    value = 88888;
    return
end
axis tight;
xlabel('wres sth diarkeia ths hmeras')
ylabel('thermokrasia')
end
