% Onomateponymo::
% AEM::
% TMHMA::

% Filename - myPlot.m
% function - myPlot(n)
% This function plots functions related to complexity
function [x, y1, y2, y3, y4] = myPlot(n)



% x=.....
% 
% y1 = .....
% y2 = .....
% y3 = ....
% y4 = ....


subplot(2,1,1);
% plot(....................);
xlabel('x');
ylabel('y');
legend('y=log_{2}(x) logaritmic','y=2^x exponential','x^2 square','x linear');
legend('Location','northwest');
title('Linear Scales');


subplot(2,1,2);
% loglog(..................);
xlabel('log(x)');
ylabel('log(y)');
legend('y=log_{2}(x) logaritmic','y=2^x exponential','x^2 square','x linear'); 
legend('Location','northwest');
title('Logarithmic Scales');
