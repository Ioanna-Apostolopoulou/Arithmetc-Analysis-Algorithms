% Onomateponymo::
% AEM::
% TMHMA::

% Filename - mycos.m
% function - mycos(x)
% This function calculates the cosine of a given angle in radians 
function [c , count] = mycos(x)

c = ...
count=0;
while (......)
    
        
    c = c +........;
   
    count=count+1;
end


