% Onomateponymo::
% AEM::
% TMHMA::

% Filename - altmatrix.m
% function - altmatrix(A)
% This function multiplies by 10 the previous of the last row
% of a given matrix A
function A = altmatrix(A)

% A(........)=.........

